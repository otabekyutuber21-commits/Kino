# 🎬 Kino Bot - Python Aiogram 3.x

Professional Telegram Kino Bot - to'liq funksional.

## 📁 Loyiha tuzilmasi

```
kinobot/
├── main.py                  # Asosiy fayl
├── config.py                # Konfiguratsiya
├── requirements.txt         # Kutubxonalar
├── .env.example             # Environment namunasi
├── database/
│   └── db.py                # SQLite bazasi va barcha SQL funksiyalar
├── handlers/
│   ├── states.py            # FSM holatlari
│   ├── user.py              # /start, obuna tekshirish
│   ├── movies.py            # Kino qidirish, ko'rish, sevimlilar
│   ├── profile.py           # Profil va referal
│   ├── support.py           # Support va zayafka (user)
│   ├── admin_movies.py      # Kino yuklash va boshqarish
│   ├── admin_channels.py    # Kanallar, broadcast, statistika
│   └── admin_panel.py       # Support admin, zayafka admin, adminlar, sozlamalar
├── keyboards/
│   └── keyboards.py         # Barcha keyboard (Reply + Inline)
├── middlewares/
│   └── flood.py             # Flood control
└── utils/
    └── helpers.py           # Yordamchi funksiyalar
```

## ⚙️ O'rnatish

### 1. Kutubxonalarni o'rnatish
```bash
pip install -r requirements.txt
```

### 2. Token va admin sozlash
`config.py` faylini oching:
```python
BOT_TOKEN = "YOUR_BOT_TOKEN"   # yoki .env da

SUPER_ADMINS = [123456789]     # Sizning Telegram ID

INITIAL_ADMINS = [
    111111111,
    222222222
]
```

Yoki `.env` fayl yarating:
```
BOT_TOKEN=your_bot_token_here
```

### 3. Botni ishga tushirish
```bash
python main.py
```

## 🔐 Admin tizimi

| Tur | Huquqlar |
|-----|----------|
| **Super Admin** | Hamma narsa: adminlar boshqaruvi, backup, sozlamalar |
| **Admin** | Kino, kanal, broadcast, support, zayafka |
| **User** | Kino ko'rish, qidirish, sevimlilar, support |

- `/admin` buyrug'i **kerak emas** — ID orqali avtomatik aniqlanadi
- Super Admin DB orqali yangi adminlar qo'sha oladi
- Yangi adminlar bazada saqlanadi

## 📋 Funksiyalar

### 👤 Foydalanuvchi
- ✅ Majburiy obuna tekshirish
- 🔍 Kod va nom orqali qidirish
- 🆕 Yangi kinolar, 🏆 Top, 🎲 Tasodifiy
- 🎭 Janrlar, 📺 Seriallar (fasl/qism)
- ❤️ Sevimlilar (qo'shish/o'chirish)
- 👤 Profil + 🔗 Referal tizimi
- 🆘 Support (to'liq chat)
- 📨 Kino so'rash (zayafka)

### 🔐 Admin
- 🎬 Kino yuklash (HD/FHD/4K)
- ✏️ Tahrirlash, 🗑 O'chirish
- 📺 Serial qo'llab-quvvatlash
- 📡 Kanal/guruh boshqaruvi
- 📊 Statistika
- 📢 Broadcast (matn/rasm/video/fayl)
- 🆘 Support javoblash
- 📋 Zayafka boshqaruvi

### 👑 Super Admin
- 👥 Adminlar qo'shish/o'chirish
- 🤖 Bot yoqish/o'chirish
- 💾 Backup yaratish
- ⚙️ Bot sozlamalari

## 🛡️ Xavfsizlik
- Flood Control (spam himoya)
- SQL Injection himoyasi (parametrli so'rovlar)
- Admin tekshiruvi (har bir so'rovda)
- Xatolar loglash (bot.log)
- Bot holati monitoring

## 📊 Log
Quyidagilar `bot.log` ga yoziladi:
- Kino qo'shildi/o'chirildi
- Kanal qo'shildi/o'chirildi
- Admin qo'shildi/o'chirildi
- Broadcast yuborildi
- Support javoblandi
- Barcha xatolar
