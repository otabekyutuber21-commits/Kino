import logging
import asyncio
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.db import (
    get_channels, add_channel, remove_channel,
    get_social_links, add_social_link, remove_social_link,
    get_all_users, get_user_stats, get_top_searched,
    get_open_tickets, get_pending_requests, add_log,
    get_setting, set_setting
)
from keyboards.keyboards import (
    admin_panel_keyboard, channels_menu_keyboard,
    cancel_keyboard, broadcast_type_keyboard
)
from handlers.states import AddChannelState, AddSocialState, BroadcastState, BroadcastSingle
from utils.helpers import is_admin, is_super_admin

logger = logging.getLogger(__name__)
router = Router()


# ==================== KANALLAR ====================

@router.message(F.text == "📡 Kanallarni sozlash")
async def channels_menu(message: Message):
    if not await is_admin(message.from_user.id):
        return
    await message.answer("📡 Kanallarni sozlash:", reply_markup=channels_menu_keyboard())


@router.message(F.text == "📋 Kanallar ro'yxati")
async def list_channels(message: Message):
    if not await is_admin(message.from_user.id):
        return
    channels = await get_channels(required_only=False)
    if not channels:
        await message.answer("📭 Hech qanday kanal yo'q.")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    text = "📋 <b>Telegram kanallar:</b>\n\n"
    for ch in channels:
        text += f"• {ch['channel_name']} | {ch['channel_id']}\n"
        builder.row(InlineKeyboardButton(
            text=f"🗑 {ch['channel_name']} o'chirish",
            callback_data=f"del_channel_{ch['id']}"
        ))
    await message.answer(text, reply_markup=builder.as_markup(), parse_mode="HTML")


@router.message(F.text == "➕ Telegram kanal qo'shish")
async def add_channel_start(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    await state.set_state(AddChannelState.waiting_channel_id)
    await message.answer(
        "📢 Kanal ID sini kiriting\n"
        "(masalan: @mychannel yoki -100123456789):",
        reply_markup=cancel_keyboard()
    )


@router.message(AddChannelState.waiting_channel_id)
async def receive_channel_id(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=channels_menu_keyboard())
        return
    await state.update_data(channel_id=message.text.strip())
    await state.set_state(AddChannelState.waiting_channel_name)
    await message.answer("📝 Kanal nomini kiriting:")


@router.message(AddChannelState.waiting_channel_name)
async def receive_channel_name(message: Message, state: FSMContext):
    await state.update_data(channel_name=message.text.strip())
    await state.set_state(AddChannelState.waiting_channel_link)
    await message.answer("🔗 Kanal havolasini kiriting (https://t.me/...):")


@router.message(AddChannelState.waiting_channel_link)
async def receive_channel_link(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    await add_channel(data["channel_id"], data["channel_name"], message.text.strip())
    await add_log("Kanal qo'shildi", message.from_user.id, data["channel_name"])
    await message.answer(
        f"✅ <b>{data['channel_name']}</b> kanali qo'shildi!",
        reply_markup=channels_menu_keyboard(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("del_channel_"))
async def delete_channel(callback: CallbackQuery):
    ch_id = int(callback.data.split("_")[-1])
    await remove_channel(ch_id)
    await add_log("Kanal o'chirildi", callback.from_user.id)
    await callback.message.answer("✅ Kanal o'chirildi!", reply_markup=channels_menu_keyboard())
    await callback.answer()


@router.message(F.text == "➕ Guruh qo'shish")
async def add_group_start(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    await state.set_state(AddChannelState.waiting_channel_id)
    await state.update_data(channel_type="group")
    await message.answer("👥 Guruh ID sini kiriting:", reply_markup=cancel_keyboard())


@router.message(F.text == "📸 Instagram qo'shish")
async def add_instagram(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    await state.set_state(AddSocialState.waiting_link)
    await state.update_data(platform="instagram")
    await message.answer("📸 Instagram havolasini kiriting:", reply_markup=cancel_keyboard())


@router.message(F.text == "▶️ YouTube qo'shish")
async def add_youtube(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    await state.set_state(AddSocialState.waiting_link)
    await state.update_data(platform="youtube")
    await message.answer("▶️ YouTube havolasini kiriting:", reply_markup=cancel_keyboard())


@router.message(AddSocialState.waiting_link)
async def receive_social_link(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=channels_menu_keyboard())
        return
    await state.update_data(link=message.text.strip())
    await state.set_state(AddSocialState.waiting_title)
    await message.answer("📝 Sarlavhani kiriting:")


@router.message(AddSocialState.waiting_title)
async def receive_social_title(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    await add_social_link(data["platform"], data["link"], message.text.strip())
    await message.answer(
        f"✅ {data['platform'].capitalize()} qo'shildi!",
        reply_markup=channels_menu_keyboard()
    )


# ==================== STATISTIKA ====================

@router.message(F.text == "📊 Statistika")
async def show_stats(message: Message):
    if not await is_admin(message.from_user.id):
        return
    stats = await get_user_stats()
    top = await get_top_searched()
    tickets = await get_open_tickets()
    requests = await get_pending_requests()

    top_text = ""
    for i, m in enumerate(top, 1):
        top_text += f"  {i}. {m['title']} - {m['views']} marta\n"

    text = (
        f"📊 <b>Bot statistikasi</b>\n\n"
        f"👥 <b>Foydalanuvchilar:</b>\n"
        f"  📌 Jami: {stats['total']}\n"
        f"  📅 Bugun: {stats['today']}\n"
        f"  📆 Hafta: {stats['week']}\n"
        f"  🗓 Oy: {stats['month']}\n\n"
        f"🎬 <b>Eng ko'p ko'rilgan kinolar:</b>\n"
        f"{top_text or '  Hali yo\\'q'}\n"
        f"🆘 <b>Ochiq supportlar:</b> {len(tickets)}\n"
        f"📋 <b>Kutilayotgan so'rovlar:</b> {len(requests)}"
    )
    await message.answer(text, parse_mode="HTML")


# ==================== XABAR YUBORISH ====================

@router.message(F.text == "📢 Xabar yuborish")
async def broadcast_menu(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📢 Hammaga", callback_data="broadcast_all"),
        InlineKeyboardButton(text="👤 Bitta userga", callback_data="broadcast_one")
    )
    await message.answer("📢 Xabar yuborish:", reply_markup=builder.as_markup())


@router.callback_query(F.data == "broadcast_all")
async def broadcast_all_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BroadcastState.waiting_type)
    await callback.message.answer(
        "📢 Xabar turini tanlang:",
        reply_markup=broadcast_type_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("broadcast_") & ~F.data.in_({"broadcast_all", "broadcast_one", "broadcast_cancel"}))
async def select_broadcast_type(callback: CallbackQuery, state: FSMContext):
    btype = callback.data.split("_")[1]
    await state.update_data(btype=btype)
    await state.set_state(BroadcastState.waiting_content)

    prompts = {
        "text": "📝 Matnni yozing:",
        "photo": "🖼 Rasmni yuboring (caption bilan):",
        "video": "🎥 Videoni yuboring:",
        "file": "📁 Faylni yuboring:"
    }
    await callback.message.answer(prompts.get(btype, "Yuboring:"), reply_markup=cancel_keyboard())
    await callback.answer()


@router.callback_query(F.data == "broadcast_cancel")
async def cancel_broadcast(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("❌ Bekor qilindi.", reply_markup=admin_panel_keyboard())
    await callback.answer()


@router.message(BroadcastState.waiting_content)
async def receive_broadcast_content(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return

    data = await state.get_data()
    await state.clear()

    users = await get_all_users()
    sent = 0
    failed = 0

    await message.answer(f"📤 {len(users)} ta userga yuborilmoqda...")

    for user_id in users:
        try:
            if message.text and data["btype"] == "text":
                await bot.send_message(user_id, message.text, parse_mode="HTML")
            elif message.photo:
                await bot.send_photo(user_id, message.photo[-1].file_id,
                                     caption=message.caption or "")
            elif message.video:
                await bot.send_video(user_id, message.video.file_id,
                                     caption=message.caption or "")
            elif message.document:
                await bot.send_document(user_id, message.document.file_id,
                                        caption=message.caption or "")
            sent += 1
            await asyncio.sleep(0.05)
        except Exception:
            failed += 1

    await add_log("Broadcast yuborildi", message.from_user.id, f"{sent}/{len(users)}")
    await message.answer(
        f"✅ <b>Broadcast tugadi!</b>\n\n"
        f"✔️ Yuborildi: {sent}\n"
        f"❌ Xato: {failed}",
        reply_markup=admin_panel_keyboard(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "broadcast_one")
async def broadcast_one_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BroadcastSingle.waiting_user_id)
    await callback.message.answer("👤 User ID ni kiriting:", reply_markup=cancel_keyboard())
    await callback.answer()


@router.message(BroadcastSingle.waiting_user_id)
async def receive_target_user(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return
    try:
        user_id = int(message.text)
    except ValueError:
        await message.answer("❌ ID raqam bo'lishi kerak!")
        return
    await state.update_data(target_id=user_id)
    await state.set_state(BroadcastSingle.waiting_message)
    await message.answer(f"✅ Maqsad: {user_id}\nXabarni yozing:")


@router.message(BroadcastSingle.waiting_message)
async def send_to_one(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    await state.clear()
    try:
        if message.text:
            await bot.send_message(data["target_id"], message.text, parse_mode="HTML")
        elif message.photo:
            await bot.send_photo(data["target_id"], message.photo[-1].file_id, caption=message.caption or "")
        elif message.video:
            await bot.send_video(data["target_id"], message.video.file_id)
        await message.answer("✅ Yuborildi!", reply_markup=admin_panel_keyboard())
    except Exception as e:
        await message.answer(f"❌ Yuborib bo'lmadi: {e}", reply_markup=admin_panel_keyboard())
