import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext

from database.db import (
    get_user, create_user, get_channels, get_setting
)
from keyboards.keyboards import (
    main_menu_keyboard, admin_panel_keyboard, super_admin_panel_keyboard,
    check_subscription_keyboard
)
from utils.helpers import is_admin, is_super_admin, check_subscription, is_bot_active

logger = logging.getLogger(__name__)
router = Router()


async def get_appropriate_keyboard(user_id: int):
    """Foydalanuvchi turiga qarab keyboard qaytarish"""
    if await is_super_admin(user_id):
        return super_admin_panel_keyboard()
    elif await is_admin(user_id):
        return admin_panel_keyboard()
    else:
        return main_menu_keyboard()


@router.message(CommandStart())
async def cmd_start(message: Message, bot: Bot, state: FSMContext):
    await state.clear()
    user_id = message.from_user.id

    # Bot holati tekshirish (adminlar uchun emas)
    if not await is_admin(user_id):
        if not await is_bot_active():
            await message.answer("🔧 Bot texnik ishlar sabab ishlamayapti. Tez orada qayta ishga tushadi!")
            return

    # Referral
    referred_by = None
    args = message.text.split()
    if len(args) > 1 and args[1].startswith("ref_"):
        try:
            referred_by = int(args[1][4:])
            if referred_by == user_id:
                referred_by = None
        except:
            pass

    # Foydalanuvchini yaratish/tekshirish
    user = await get_user(user_id)
    if not user:
        await create_user(
            user_id,
            message.from_user.username or "",
            message.from_user.full_name or "",
            referred_by
        )

    # Admin/Super Admin uchun to'g'ridan panel
    if await is_super_admin(user_id):
        await message.answer(
            "👑 Super Admin panelga xush kelibsiz!",
            reply_markup=super_admin_panel_keyboard()
        )
        return
    elif await is_admin(user_id):
        await message.answer(
            "🔐 Admin panelga xush kelibsiz!",
            reply_markup=admin_panel_keyboard()
        )
        return

    # Obuna tekshirish
    is_subscribed, not_subscribed = await check_subscription(bot, user_id)

    if not is_subscribed:
        start_text = await get_setting("start_text",
            "🎬 Xush kelibsiz! Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling 👇")
        await message.answer(
            start_text,
            reply_markup=check_subscription_keyboard(not_subscribed)
        )
        return

    # Asosiy menyu
    await message.answer(
        "🎬 <b>Kino Bot</b>ga xush kelibsiz!\n\n"
        "Quyidagi menyudan foydalanib kinolarni topin:",
        reply_markup=main_menu_keyboard(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "check_sub")
async def check_subscription_callback(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    is_subscribed, not_subscribed = await check_subscription(bot, user_id)

    if not is_subscribed:
        await callback.answer("❌ Siz hali barcha kanallarga obuna bo'lmadingiz!", show_alert=True)
        await callback.message.edit_reply_markup(
            reply_markup=check_subscription_keyboard(not_subscribed)
        )
        return

    await callback.message.delete()
    await callback.message.answer(
        "✅ Obuna tasdiqlandi!\n\n🎬 <b>Kino Bot</b>ga xush kelibsiz!",
        reply_markup=main_menu_keyboard(),
        parse_mode="HTML"
    )


@router.message(F.text == "🏠 Asosiy menyu")
async def main_menu(message: Message, state: FSMContext):
    await state.clear()
    kb = await get_appropriate_keyboard(message.from_user.id)
    await message.answer("🏠 Asosiy menyu", reply_markup=kb)
