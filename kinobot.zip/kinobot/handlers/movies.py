import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.db import (
    get_movie_by_code, get_movie_by_id, search_movies_by_title,
    get_latest_movies, get_top_movies, get_random_movie,
    get_movies_by_genre, get_genres, get_serials, get_serial_episodes,
    get_movie_files, increment_views, add_favorite, remove_favorite,
    get_favorites, is_favorite
)
from keyboards.keyboards import (
    movie_keyboard, quality_keyboard, genres_keyboard,
    serials_keyboard, episodes_keyboard, favorites_keyboard,
    back_keyboard, cancel_keyboard
)
from utils.helpers import format_movie_info, format_serial_info, check_subscription
from handlers.states import MovieSearch
from aiogram.fsm.context import FSMContext

logger = logging.getLogger(__name__)
router = Router()


async def send_movie(message_or_callback, bot: Bot, movie, user_id: int):
    """Kinoni yuborish - video/fayl bilan"""
    files = await get_movie_files(movie["id"])
    await increment_views(movie["id"])
    fav = await is_favorite(user_id, movie["id"])
    info_text = format_movie_info(movie)

    if not files:
        await (message_or_callback.message if hasattr(message_or_callback, 'message')
               else message_or_callback).answer(
            f"{info_text}\n\n❌ Hozircha video mavjud emas.",
            reply_markup=movie_keyboard(movie["id"], fav),
            parse_mode="HTML"
        )
        return

    # Bitta sifat bo'lsa to'g'ridan yuborish
    if len(files) == 1:
        f = files[0]
        target = message_or_callback.message if hasattr(message_or_callback, 'message') else message_or_callback
        if f["file_type"] == "video":
            await target.answer_video(
                f["file_id"],
                caption=info_text,
                reply_markup=movie_keyboard(movie["id"], fav),
                parse_mode="HTML"
            )
        else:
            await target.answer_document(
                f["file_id"],
                caption=info_text,
                reply_markup=movie_keyboard(movie["id"], fav),
                parse_mode="HTML"
            )
    else:
        # Bir necha sifat - tanlash
        target = message_or_callback.message if hasattr(message_or_callback, 'message') else message_or_callback
        await target.answer(
            f"{info_text}\n\n🎬 Sifatni tanlang:",
            reply_markup=quality_keyboard(movie["id"], files),
            parse_mode="HTML"
        )


# ==================== KINO QIDIRISH ====================

@router.message(F.text == "🔍 Kino qidirish")
async def start_search(message: Message, state: FSMContext):
    await state.set_state(MovieSearch.waiting_query)
    await message.answer(
        "🔍 Kino kodi yoki nomini kiriting:\n\n"
        "<i>Misol: 1001 yoki 'Avatar'</i>",
        reply_markup=cancel_keyboard(),
        parse_mode="HTML"
    )


@router.message(MovieSearch.waiting_query)
async def process_search(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        from keyboards.keyboards import main_menu_keyboard
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return

    query = message.text.strip()
    await state.clear()

    # Kod orqali qidirish
    movie = await get_movie_by_code(query)
    if movie:
        await send_movie(message, bot, movie, message.from_user.id)
        return

    # Nom orqali qidirish
    movies = await search_movies_by_title(query)
    if not movies:
        await message.answer(
            f"❌ '<b>{query}</b>' bo'yicha kino topilmadi.\n\n"
            "📨 Kino so'rash uchun: <b>Taklif va murojaat</b> bo'limiga murojaat qiling.",
            parse_mode="HTML"
        )
        return

    if len(movies) == 1:
        await send_movie(message, bot, movies[0], message.from_user.id)
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for m in movies[:10]:
        builder.row(InlineKeyboardButton(
            text=f"🎬 {m['title']} ({m['movie_code']})",
            callback_data=f"movie_{m['movie_code']}"
        ))
    await message.answer(
        f"🔍 '<b>{query}</b>' bo'yicha {len(movies)} ta kino topildi:",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )


# Kino kodi to'g'ridan yuborganda
@router.message(F.text.regexp(r'^\d{3,6}$'))
async def direct_code_search(message: Message, bot: Bot):
    movie = await get_movie_by_code(message.text.strip())
    if movie:
        await send_movie(message, bot, movie, message.from_user.id)
    else:
        await message.answer(f"❌ <b>{message.text}</b> kodli kino topilmadi.", parse_mode="HTML")


@router.callback_query(F.data.startswith("movie_"))
async def movie_by_code_callback(callback: CallbackQuery, bot: Bot):
    code = callback.data.split("_", 1)[1]
    movie = await get_movie_by_code(code)
    if movie:
        await send_movie(callback, bot, movie, callback.from_user.id)
    await callback.answer()


@router.callback_query(F.data.startswith("play_"))
async def play_quality(callback: CallbackQuery):
    file_id_pk = int(callback.data.split("_")[1])
    import aiosqlite
    async with aiosqlite.connect("kinobot.db") as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM movie_files WHERE id = ?", (file_id_pk,))
        f = await cursor.fetchone()
    if not f:
        await callback.answer("❌ Fayl topilmadi", show_alert=True)
        return
    if f["file_type"] == "video":
        await callback.message.answer_video(f["file_id"])
    else:
        await callback.message.answer_document(f["file_id"])
    await callback.answer()


# ==================== ENG YANGI / TOP ====================

@router.message(F.text == "🆕 Eng yangi kinolar")
async def latest_movies(message: Message, bot: Bot):
    movies = await get_latest_movies(10)
    if not movies:
        await message.answer("📭 Hozircha kinolar yo'q.")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for m in movies:
        builder.row(InlineKeyboardButton(
            text=f"🎬 {m['title']} ({m['year'] or '?'})",
            callback_data=f"movie_{m['movie_code']}"
        ))
    await message.answer("🆕 <b>Eng yangi kinolar:</b>", reply_markup=builder.as_markup(), parse_mode="HTML")


@router.message(F.text == "🏆 Top kinolar")
async def top_movies(message: Message):
    movies = await get_top_movies(10)
    if not movies:
        await message.answer("📭 Hozircha kinolar yo'q.")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for i, m in enumerate(movies, 1):
        builder.row(InlineKeyboardButton(
            text=f"#{i} {m['title']} 👁{m['views']}",
            callback_data=f"movie_{m['movie_code']}"
        ))
    await message.answer("🏆 <b>Top kinolar:</b>", reply_markup=builder.as_markup(), parse_mode="HTML")


@router.message(F.text == "🎲 Tasodifiy kino")
async def random_movie(message: Message, bot: Bot):
    movie = await get_random_movie()
    if not movie:
        await message.answer("📭 Hozircha kinolar yo'q.")
        return
    await send_movie(message, bot, movie, message.from_user.id)


# ==================== JANRLAR ====================

@router.message(F.text == "🎭 Janrlar")
async def show_genres(message: Message):
    genres = await get_genres()
    if not genres:
        await message.answer("📭 Hozircha janrlar yo'q.")
        return
    await message.answer(
        "🎭 <b>Janrni tanlang:</b>",
        reply_markup=genres_keyboard(genres),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("genre_"))
async def show_genre_movies(callback: CallbackQuery):
    genre = callback.data.split("_", 1)[1]
    movies = await get_movies_by_genre(genre, 15)
    if not movies:
        await callback.answer(f"❌ '{genre}' janrida kino topilmadi", show_alert=True)
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for m in movies:
        builder.row(InlineKeyboardButton(
            text=f"🎬 {m['title']}",
            callback_data=f"movie_{m['movie_code']}"
        ))
    await callback.message.answer(
        f"🎭 <b>{genre}</b> janridagi kinolar:",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )
    await callback.answer()


# ==================== SERIALLAR ====================

@router.message(F.text == "📺 Seriallar")
async def show_serials(message: Message):
    serials = await get_serials()
    if not serials:
        await message.answer("📭 Hozircha seriallar yo'q.")
        return
    await message.answer(
        "📺 <b>Seriallar:</b>",
        reply_markup=serials_keyboard(serials),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("serial_"))
async def show_serial_episodes(callback: CallbackQuery):
    serial_code = callback.data.split("_", 1)[1]
    episodes = await get_serial_episodes(serial_code)
    if not episodes:
        await callback.answer("❌ Qismlar topilmadi", show_alert=True)
        return
    title = episodes[0]["title"]
    await callback.message.answer(
        f"📺 <b>{title}</b>\n\nQismni tanlang:",
        reply_markup=episodes_keyboard(episodes),
        parse_mode="HTML"
    )
    await callback.answer()


# ==================== SEVIMLILAR ====================

@router.message(F.text == "❤️ Sevimlilar")
async def show_favorites(message: Message):
    movies = await get_favorites(message.from_user.id)
    if not movies:
        await message.answer("💔 Sevimlilar ro'yxatingiz bo'sh.")
        return
    await message.answer(
        f"❤️ <b>Sevimli kinolaringiz ({len(movies)} ta):</b>",
        reply_markup=favorites_keyboard(movies),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("fav_"))
async def add_to_favorites(callback: CallbackQuery):
    movie_id = int(callback.data.split("_")[1])
    result = await add_favorite(callback.from_user.id, movie_id)
    if result:
        await callback.answer("❤️ Sevimlilarga qo'shildi!", show_alert=True)
        movie = await get_movie_by_id(movie_id)
        if callback.message.reply_markup and movie:
            await callback.message.edit_reply_markup(
                reply_markup=movie_keyboard(movie_id, True)
            )
    else:
        await callback.answer("⚠️ Allaqachon qo'shilgan!", show_alert=True)


@router.callback_query(F.data.startswith("unfav_"))
async def remove_from_favorites(callback: CallbackQuery):
    movie_id = int(callback.data.split("_")[1])
    await remove_favorite(callback.from_user.id, movie_id)
    await callback.answer("💔 Sevimlilardan o'chirildi!", show_alert=True)
    await callback.message.edit_reply_markup(
        reply_markup=movie_keyboard(movie_id, False)
    )
