import logging
import json
import os
from datetime import datetime
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.fsm.context import FSMContext

from database.db import (
    get_open_tickets, get_support_ticket, reply_support,
    close_support_ticket, add_chat_message,
    get_pending_requests, get_request, update_request,
    get_all_admins_info, add_admin, remove_admin,
    get_setting, set_setting, add_log, get_user
)
from keyboards.keyboards import (
    admin_panel_keyboard, cancel_keyboard,
    support_admin_keyboard, request_admin_keyboard
)
from handlers.states import AdminSupportState, AdminReplyRequest, AddAdminState, SettingsState
from utils.helpers import is_admin, is_super_admin
from config import SUPER_ADMINS

logger = logging.getLogger(__name__)
router = Router()


# ==================== ADMIN SUPPORT ====================

@router.message(F.text == "🆘 Support [Admin]")
async def admin_support_menu(message: Message):
    if not await is_admin(message.from_user.id):
        return
    tickets = await get_open_tickets()
    if not tickets:
        await message.answer("✅ Hech qanday ochiq support yo'q.")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for t in tickets:
        preview = (t["user_message"] or "")[:30]
        builder.row(InlineKeyboardButton(
            text=f"#{t['id']} | {preview}...",
            callback_data=f"view_ticket_{t['id']}"
        ))
    await message.answer(
        f"🆘 <b>Ochiq supportlar ({len(tickets)}):</b>",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("view_ticket_"))
async def view_ticket(callback: CallbackQuery):
    ticket_id = int(callback.data.split("_")[-1])
    ticket = await get_support_ticket(ticket_id)
    if not ticket:
        await callback.answer("❌ Topilmadi", show_alert=True)
        return

    user = await get_user(ticket["user_id"])
    username = f"@{user['username']}" if user and user["username"] else "yo'q"

    text = (
        f"🎫 <b>Ticket #{ticket_id}</b>\n\n"
        f"👤 User: <code>{ticket['user_id']}</code> {username}\n"
        f"📅 Sana: {str(ticket['created_at'])[:16]}\n"
        f"🔄 Holat: {ticket['status']}\n\n"
        f"💬 <b>Xabar:</b>\n{ticket['user_message']}"
    )
    await callback.message.answer(text, reply_markup=support_admin_keyboard(ticket_id), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("reply_ticket_"))
async def start_reply_ticket(callback: CallbackQuery, state: FSMContext):
    ticket_id = int(callback.data.split("_")[-1])
    await state.set_state(AdminSupportState.replying)
    await state.update_data(ticket_id=ticket_id)
    await callback.message.answer(
        f"💬 Ticket #{ticket_id} ga javob yozing:", reply_markup=cancel_keyboard()
    )
    await callback.answer()


@router.message(AdminSupportState.replying)
async def send_reply_to_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return

    data = await state.get_data()
    ticket_id = data["ticket_id"]
    ticket = await get_support_ticket(ticket_id)
    await state.clear()

    if not ticket:
        await message.answer("❌ Ticket topilmadi.")
        return

    await reply_support(ticket_id, message.from_user.id, message.text)
    await add_log("Support javoblandi", message.from_user.id, f"Ticket #{ticket_id}")

    # Foydalanuvchiga yuborish
    try:
        await bot.send_message(
            ticket["user_id"],
            f"💬 <b>Support javobi (#{ticket_id}):</b>\n\n{message.text}",
            parse_mode="HTML"
        )
        await message.answer("✅ Javob yuborildi!", reply_markup=admin_panel_keyboard())
    except Exception as e:
        await message.answer(f"❌ Foydalanuvchiga yuborib bo'lmadi: {e}", reply_markup=admin_panel_keyboard())


@router.callback_query(F.data.startswith("close_ticket_"))
async def close_ticket(callback: CallbackQuery, bot: Bot):
    ticket_id = int(callback.data.split("_")[-1])
    ticket = await get_support_ticket(ticket_id)
    await close_support_ticket(ticket_id)
    if ticket:
        try:
            await bot.send_message(
                ticket["user_id"],
                f"✅ Support #{ticket_id} yopildi. Murojaat uchun rahmat!"
            )
        except:
            pass
    await callback.message.answer("✅ Ticket yopildi!", reply_markup=admin_panel_keyboard())
    await callback.answer()


# ==================== ZAYAFKALAR ====================

@router.message(F.text == "📋 Zayafkalar")
async def admin_requests(message: Message):
    if not await is_admin(message.from_user.id):
        return
    requests = await get_pending_requests()
    if not requests:
        await message.answer("✅ Kutilayotgan so'rovlar yo'q.")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for r in requests:
        builder.row(InlineKeyboardButton(
            text=f"#{r['id']} {r['movie_name']}",
            callback_data=f"view_req_{r['id']}"
        ))
    await message.answer(
        f"📋 <b>Kino so'rovlari ({len(requests)}):</b>",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("view_req_"))
async def view_request(callback: CallbackQuery):
    req_id = int(callback.data.split("_")[-1])
    req = await get_request(req_id)
    if not req:
        await callback.answer("❌ Topilmadi", show_alert=True)
        return

    text = (
        f"📋 <b>So'rov #{req_id}</b>\n\n"
        f"👤 User: <code>{req['user_id']}</code>\n"
        f"🎬 <b>Kino:</b> {req['movie_name']}\n"
        f"📝 <b>Qo'shimcha:</b> {req['description'] or 'Yo\\'q'}\n"
        f"📅 Sana: {str(req['created_at'])[:16]}"
    )
    await callback.message.answer(text, reply_markup=request_admin_keyboard(req_id), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("accept_req_"))
async def accept_request(callback: CallbackQuery, bot: Bot):
    req_id = int(callback.data.split("_")[-1])
    req = await get_request(req_id)
    await update_request(req_id, "accepted", callback.from_user.id, "So'rovingiz qabul qilindi!")
    if req:
        try:
            await bot.send_message(
                req["user_id"],
                f"✅ <b>So'rovingiz qabul qilindi!</b>\n\n"
                f"🎬 Kino: {req['movie_name']}\n"
                f"Tez orada yuklanadi.",
                parse_mode="HTML"
            )
        except:
            pass
    await callback.message.answer("✅ Qabul qilindi!", reply_markup=admin_panel_keyboard())
    await callback.answer()


@router.callback_query(F.data.startswith("reject_req_"))
async def reject_request(callback: CallbackQuery, bot: Bot):
    req_id = int(callback.data.split("_")[-1])
    req = await get_request(req_id)
    await update_request(req_id, "rejected", callback.from_user.id, "So'rovingiz rad etildi.")
    if req:
        try:
            await bot.send_message(
                req["user_id"],
                f"❌ <b>So'rovingiz rad etildi.</b>\n\n"
                f"🎬 Kino: {req['movie_name']}",
                parse_mode="HTML"
            )
        except:
            pass
    await callback.message.answer("❌ Rad etildi.", reply_markup=admin_panel_keyboard())
    await callback.answer()


@router.callback_query(F.data.startswith("reply_req_"))
async def reply_to_request(callback: CallbackQuery, state: FSMContext):
    req_id = int(callback.data.split("_")[-1])
    await state.set_state(AdminReplyRequest.replying)
    await state.update_data(req_id=req_id)
    await callback.message.answer(
        f"💬 So'rov #{req_id} ga javob yozing:", reply_markup=cancel_keyboard()
    )
    await callback.answer()


@router.message(AdminReplyRequest.replying)
async def send_req_reply(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return

    data = await state.get_data()
    req = await get_request(data["req_id"])
    await update_request(data["req_id"], "replied", message.from_user.id, message.text)
    await state.clear()

    if req:
        try:
            await bot.send_message(
                req["user_id"],
                f"💬 <b>Kino so'rovingizga javob:</b>\n\n{message.text}",
                parse_mode="HTML"
            )
        except:
            pass
    await message.answer("✅ Javob yuborildi!", reply_markup=admin_panel_keyboard())


# ==================== ADMINLAR ====================

@router.message(F.text == "👥 Adminlar")
async def admins_menu(message: Message):
    if not await is_super_admin(message.from_user.id):
        await message.answer("❌ Faqat Super Admin uchun!")
        return

    admins = await get_all_admins_info()
    from config import INITIAL_ADMINS

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Admin qo'shish", callback_data="add_admin"))

    text = f"👥 <b>Adminlar ({len(admins)}):</b>\n\n"
    for a in admins:
        text += f"• <code>{a['telegram_id']}</code> (qo'shilgan: {str(a['added_at'])[:10]})\n"
        builder.row(InlineKeyboardButton(
            text=f"🗑 {a['telegram_id']} o'chirish",
            callback_data=f"del_admin_{a['telegram_id']}"
        ))

    text += f"\n📌 <b>Config adminlar:</b>\n"
    for a in INITIAL_ADMINS:
        text += f"• <code>{a}</code>\n"

    await message.answer(text, reply_markup=builder.as_markup(), parse_mode="HTML")


@router.callback_query(F.data == "add_admin")
async def add_admin_start(callback: CallbackQuery, state: FSMContext):
    if not await is_super_admin(callback.from_user.id):
        await callback.answer("❌ Ruxsat yo'q!", show_alert=True)
        return
    await state.set_state(AddAdminState.waiting_id)
    await callback.message.answer("👤 Yangi admin Telegram ID sini kiriting:", reply_markup=cancel_keyboard())
    await callback.answer()


@router.message(AddAdminState.waiting_id)
async def receive_admin_id(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return
    try:
        admin_id = int(message.text)
    except ValueError:
        await message.answer("❌ ID raqam bo'lishi kerak!")
        return

    await add_admin(admin_id, message.from_user.id)
    await add_log("Admin qo'shildi", message.from_user.id, str(admin_id))
    await state.clear()
    await message.answer(f"✅ Admin qo'shildi: <code>{admin_id}</code>", parse_mode="HTML",
                        reply_markup=admin_panel_keyboard())


@router.callback_query(F.data.startswith("del_admin_"))
async def delete_admin(callback: CallbackQuery):
    if not await is_super_admin(callback.from_user.id):
        await callback.answer("❌ Ruxsat yo'q!", show_alert=True)
        return
    admin_id = int(callback.data.split("_")[-1])
    await remove_admin(admin_id)
    await add_log("Admin o'chirildi", callback.from_user.id, str(admin_id))
    await callback.message.answer(f"✅ Admin o'chirildi: {admin_id}", reply_markup=admin_panel_keyboard())
    await callback.answer()


# ==================== BOT HOLATI ====================

@router.message(F.text == "🤖 Bot holati")
async def bot_status(message: Message):
    if not await is_super_admin(message.from_user.id):
        if not await is_admin(message.from_user.id):
            return
    status = await get_setting("bot_status", "on")
    from keyboards.keyboards import bot_status_keyboard
    status_text = "🟢 Ishlayapti" if status == "on" else "🔴 To'xtatilgan"
    await message.answer(
        f"🤖 <b>Bot holati:</b> {status_text}",
        reply_markup=bot_status_keyboard(status),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("bot_status_"))
async def change_bot_status(callback: CallbackQuery, bot: Bot):
    if not await is_super_admin(callback.from_user.id):
        await callback.answer("❌ Ruxsat yo'q!", show_alert=True)
        return
    new_status = callback.data.split("_")[-1]
    await set_setting("bot_status", new_status)

    status_text = "🟢 Yoqildi" if new_status == "on" else "🔴 O'chirildi"
    await callback.message.answer(f"✅ Bot holati: {status_text}", reply_markup=admin_panel_keyboard())
    await callback.answer()


# ==================== BACKUP ====================

@router.message(F.text == "💾 Backup")
async def backup_menu(message: Message):
    if not await is_super_admin(message.from_user.id):
        await message.answer("❌ Faqat Super Admin uchun!")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="📥 Backup yaratish", callback_data="create_backup"))
    await message.answer("💾 Backup boshqaruvi:", reply_markup=builder.as_markup())


@router.callback_query(F.data == "create_backup")
async def create_backup(callback: CallbackQuery, bot: Bot):
    if not await is_super_admin(callback.from_user.id):
        await callback.answer("❌ Ruxsat yo'q!", show_alert=True)
        return
    try:
        if os.path.exists("kinobot.db"):
            backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            import shutil
            shutil.copy("kinobot.db", backup_name)
            doc = FSInputFile(backup_name)
            await bot.send_document(
                callback.from_user.id,
                doc,
                caption=f"💾 Backup: {backup_name}"
            )
            os.remove(backup_name)
            await callback.message.answer("✅ Backup yuborildi!")
        else:
            await callback.message.answer("❌ Database topilmadi.")
    except Exception as e:
        await callback.message.answer(f"❌ Xato: {e}")
    await callback.answer()


# ==================== SOZLAMALAR ====================

@router.message(F.text == "⚙️ Sozlamalar")
async def settings_menu(message: Message):
    if not await is_super_admin(message.from_user.id):
        await message.answer("❌ Faqat Super Admin uchun!")
        return

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    settings_list = [
        ("bot_name", "🤖 Bot nomi"),
        ("start_text", "👋 Start xabari"),
        ("support_text", "🆘 Support xabari"),
        ("ad_text", "📢 Reklama xabari"),
    ]
    for key, label in settings_list:
        builder.row(InlineKeyboardButton(text=label, callback_data=f"edit_setting_{key}"))
    await message.answer("⚙️ <b>Sozlamalar:</b>", reply_markup=builder.as_markup(), parse_mode="HTML")


@router.callback_query(F.data.startswith("edit_setting_"))
async def edit_setting(callback: CallbackQuery, state: FSMContext):
    key = callback.data.split("edit_setting_")[1]
    await state.set_state(SettingsState.waiting_value)
    await state.update_data(setting_key=key)
    current = await get_setting(key, "")
    await callback.message.answer(
        f"✏️ Yangi qiymatni kiriting:\n\n"
        f"<b>Hozirgi:</b> {current[:100] if current else 'bo\\'sh'}",
        reply_markup=cancel_keyboard(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(SettingsState.waiting_value)
async def save_setting(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return

    data = await state.get_data()
    await set_setting(data["setting_key"], message.text)
    await state.clear()
    await message.answer("✅ Saqlandi!", reply_markup=admin_panel_keyboard())
