import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.db import (
    create_support_ticket, get_user_open_ticket,
    add_chat_message, get_support_ticket,
    create_request, get_setting
)
from keyboards.keyboards import main_menu_keyboard, cancel_keyboard
from handlers.states import SupportState, RequestState
from utils.helpers import is_admin, get_db_admins
from config import SUPER_ADMINS, INITIAL_ADMINS
from database.db import get_db_admins as db_get_admins

logger = logging.getLogger(__name__)
router = Router()


async def notify_admins(bot: Bot, text: str, reply_markup=None):
    """Barcha adminlarga xabar yuborish"""
    all_admins = set(SUPER_ADMINS + INITIAL_ADMINS + await db_get_admins())
    for admin_id in all_admins:
        try:
            await bot.send_message(admin_id, text, reply_markup=reply_markup, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Admin notify error {admin_id}: {e}")


# ==================== SUPPORT ====================

@router.message(F.text == "🆘 Support")
async def support_menu(message: Message, state: FSMContext):
    support_text = await get_setting("support_text", "Savolingizni yozing, adminlar javob beradi:")
    await state.set_state(SupportState.waiting_message)
    await message.answer(
        f"🆘 <b>Support</b>\n\n{support_text}",
        reply_markup=cancel_keyboard(),
        parse_mode="HTML"
    )


@router.message(SupportState.waiting_message)
async def receive_support_message(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return

    text = message.text or message.caption or "[Fayl]"
    ticket_id = await create_support_ticket(message.from_user.id, text)

    await state.update_data(ticket_id=ticket_id)
    await state.set_state(SupportState.in_chat)

    await message.answer(
        "✅ Xabaringiz yuborildi! Admin javob berguncha kuting.\n\n"
        "Davom etish uchun yangi xabar yuboring yoki /cancel bilan chiqing.",
        reply_markup=cancel_keyboard()
    )

    # Adminlarga xabardor qilish
    from keyboards.keyboards import support_admin_keyboard
    user = message.from_user
    notify_text = (
        f"🆘 <b>Yangi support xabari</b>\n\n"
        f"👤 <b>User ID:</b> <code>{user.id}</code>\n"
        f"📛 <b>Username:</b> @{user.username or 'yo\\'q'}\n"
        f"👤 <b>Ism:</b> {user.full_name}\n\n"
        f"💬 <b>Xabar:</b>\n{text}\n\n"
        f"🎫 <b>Ticket #</b>{ticket_id}"
    )
    await notify_admins(bot, notify_text, support_admin_keyboard(ticket_id))


@router.message(SupportState.in_chat)
async def continue_support_chat(message: Message, state: FSMContext, bot: Bot):
    if message.text in ["❌ Bekor qilish", "/cancel"]:
        await state.clear()
        await message.answer("Support chat yopildi.", reply_markup=main_menu_keyboard())
        return

    data = await state.get_data()
    ticket_id = data.get("ticket_id")
    if not ticket_id:
        await state.clear()
        return

    text = message.text or message.caption or "[Fayl]"
    await add_chat_message(ticket_id, message.from_user.id, "user", text)

    # Adminlarga yuborish
    user = message.from_user
    notify_text = (
        f"💬 <b>Support davom (Ticket #{ticket_id})</b>\n\n"
        f"👤 User: <code>{user.id}</code> @{user.username or ''}\n\n"
        f"📩 {text}"
    )
    from keyboards.keyboards import support_admin_keyboard
    await notify_admins(bot, notify_text, support_admin_keyboard(ticket_id))


# ==================== TAKLIF VA MUROJAAT (ZAYAFKA) ====================

@router.message(F.text == "📨 Taklif va murojaat")
async def request_menu(message: Message, state: FSMContext):
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎬 Kino so'rash", callback_data="start_request"),
        InlineKeyboardButton(text="💡 Taklif yuborish", callback_data="send_suggestion")
    )
    await message.answer(
        "📨 <b>Taklif va murojaat</b>\n\nNimani xohlaysiz?",
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "start_request")
async def start_movie_request(callback: CallbackQuery, state: FSMContext):
    await state.set_state(RequestState.waiting_name)
    await callback.message.answer(
        "🎬 Qaysi kino kerak? Kino nomini yozing:",
        reply_markup=cancel_keyboard()
    )
    await callback.answer()


@router.message(RequestState.waiting_name)
async def receive_request_name(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return
    await state.update_data(movie_name=message.text)
    await state.set_state(RequestState.waiting_description)
    await message.answer(
        "📝 Qo'shimcha ma'lumot yozing (ixtiyoriy):\n"
        "(Yil, rejissyor, aktor nomi va h.k.)\n\n"
        "Yoki o'tkazib yuborish uchun /skip yozing:"
    )


@router.message(RequestState.waiting_description)
async def receive_request_desc(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return

    data = await state.get_data()
    desc = "" if message.text == "/skip" else (message.text or "")
    request_id = await create_request(message.from_user.id, data["movie_name"], desc)
    await state.clear()

    await message.answer(
        f"✅ So'rovingiz #{request_id} raqami bilan yuborildi!\n"
        "Adminlar ko'rib chiqadi va javob beradi.",
        reply_markup=main_menu_keyboard()
    )

    # Adminlarga
    from keyboards.keyboards import request_admin_keyboard
    user = message.from_user
    notify_text = (
        f"📋 <b>Yangi kino so'rovi #{request_id}</b>\n\n"
        f"👤 User: <code>{user.id}</code> @{user.username or ''}\n\n"
        f"🎬 <b>Kino:</b> {data['movie_name']}\n"
        f"📝 <b>Qo'shimcha:</b> {desc or 'Yo\\'q'}"
    )
    await notify_admins(bot, notify_text, request_admin_keyboard(request_id))


@router.callback_query(F.data == "send_suggestion")
async def send_suggestion(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SupportState.waiting_message)
    await callback.message.answer(
        "💡 Taklifingizni yozing:", reply_markup=cancel_keyboard()
    )
    await callback.answer()
