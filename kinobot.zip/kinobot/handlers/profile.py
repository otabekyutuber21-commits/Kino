import logging
from aiogram import Router, F
from aiogram.types import Message

from database.db import get_user

logger = logging.getLogger(__name__)
router = Router()


@router.message(F.text == "👤 Profil")
async def show_profile(message: Message):
    user = await get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi.")
        return

    bot_username = (await message.bot.get_me()).username
    ref_link = f"https://t.me/{bot_username}?start=ref_{message.from_user.id}"

    joined = user["joined_at"][:10] if user["joined_at"] else "Noma'lum"

    text = (
        f"👤 <b>Profil</b>\n\n"
        f"🆔 <b>Telegram ID:</b> <code>{user['telegram_id']}</code>\n"
        f"👤 <b>Username:</b> @{user['username'] or 'yo\'q'}\n"
        f"📅 <b>Ro'yxatdan o'tgan:</b> {joined}\n"
        f"👥 <b>Taklif qilganlar:</b> {user['referral_count']} ta\n\n"
        f"🔗 <b>Referal link:</b>\n"
        f"<code>{ref_link}</code>"
    )
    await message.answer(text, parse_mode="HTML")
