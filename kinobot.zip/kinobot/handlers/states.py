from aiogram.fsm.state import State, StatesGroup


class MovieUpload(StatesGroup):
    waiting_file = State()
    waiting_quality = State()
    waiting_code = State()
    waiting_title = State()
    waiting_description = State()
    waiting_genre = State()
    waiting_year = State()
    waiting_rating = State()
    waiting_is_serial = State()
    waiting_season = State()
    waiting_episode = State()
    waiting_serial_code = State()
    confirm = State()


class MovieEdit(StatesGroup):
    waiting_field = State()
    waiting_value = State()


class MovieSearch(StatesGroup):
    waiting_query = State()


class BroadcastState(StatesGroup):
    waiting_type = State()
    waiting_content = State()
    waiting_button = State()
    confirm = State()


class SupportState(StatesGroup):
    waiting_message = State()
    in_chat = State()


class AdminSupportState(StatesGroup):
    replying = State()


class RequestState(StatesGroup):
    waiting_name = State()
    waiting_description = State()


class AdminReplyRequest(StatesGroup):
    replying = State()


class AddChannelState(StatesGroup):
    waiting_channel_id = State()
    waiting_channel_name = State()
    waiting_channel_link = State()


class AddSocialState(StatesGroup):
    waiting_platform = State()
    waiting_link = State()
    waiting_title = State()


class AddAdminState(StatesGroup):
    waiting_id = State()


class BroadcastSingle(StatesGroup):
    waiting_user_id = State()
    waiting_message = State()


class SettingsState(StatesGroup):
    waiting_value = State()
