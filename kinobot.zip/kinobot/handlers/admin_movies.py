import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.db import (
    add_movie, add_movie_file, get_all_movies, get_movie_by_id,
    update_movie, delete_movie, add_log
)
from keyboards.keyboards import (
    admin_panel_keyboard, cancel_keyboard, movies_list_keyboard,
    admin_movie_keyboard, movie_quality_select_keyboard
)
from handlers.states import MovieUpload, MovieEdit
from utils.helpers import is_admin

logger = logging.getLogger(__name__)
router = Router()


# ==================== KINO YUKLASH ====================

@router.message(F.text == "🎬 Kino yuklash")
async def start_movie_upload(message: Message, state: FSMContext):
    if not await is_admin(message.from_user.id):
        return
    await state.set_state(MovieUpload.waiting_file)
    await message.answer(
        "🎬 <b>Yangi kino yuklash</b>\n\n"
        "Video yuboring (yoki fayl sifatida):",
        reply_markup=cancel_keyboard(),
        parse_mode="HTML"
    )


@router.message(MovieUpload.waiting_file, F.video | F.document)
async def receive_movie_file(message: Message, state: FSMContext):
    if message.video:
        file_id = message.video.file_id
        file_type = "video"
    elif message.document:
        file_id = message.document.file_id
        file_type = "document"
    else:
        await message.answer("❌ Video yoki fayl yuboring!")
        return

    await state.update_data(file_id=file_id, file_type=file_type)
    await state.set_state(MovieUpload.waiting_quality)
    await message.answer(
        "📺 Sifatni tanlang:",
        reply_markup=movie_quality_select_keyboard()
    )


@router.callback_query(MovieUpload.waiting_quality, F.data.startswith("quality_"))
async def receive_quality(callback: CallbackQuery, state: FSMContext):
    quality_map = {"quality_HD": "HD", "quality_FHD": "Full HD", "quality_4K": "4K"}
    quality = quality_map.get(callback.data, "HD")
    await state.update_data(quality=quality)
    await state.set_state(MovieUpload.waiting_code)
    await callback.message.answer(
        f"✅ Sifat: <b>{quality}</b>\n\n"
        "📌 Kino kodini kiriting (masalan: 1001):",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(MovieUpload.waiting_code)
async def receive_movie_code(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=admin_panel_keyboard())
        return
    await state.update_data(movie_code=message.text.strip())
    await state.set_state(MovieUpload.waiting_title)
    await message.answer("🎬 Kino nomini kiriting:")


@router.message(MovieUpload.waiting_title)
async def receive_movie_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text.strip())
    await state.set_state(MovieUpload.waiting_description)
    await message.answer("📝 Tavsif yozing (yoki /skip):")


@router.message(MovieUpload.waiting_description)
async def receive_movie_description(message: Message, state: FSMContext):
    desc = "" if message.text == "/skip" else message.text
    await state.update_data(description=desc)
    await state.set_state(MovieUpload.waiting_genre)
    await message.answer(
        "🎭 Janrni kiriting (masalan: Komediya, Dram):\n"
        "(yoki /skip)"
    )


@router.message(MovieUpload.waiting_genre)
async def receive_movie_genre(message: Message, state: FSMContext):
    genre = "" if message.text == "/skip" else message.text
    await state.update_data(genre=genre)
    await state.set_state(MovieUpload.waiting_year)
    await message.answer("📅 Yilini kiriting (masalan: 2023):\n(yoki /skip)")


@router.message(MovieUpload.waiting_year)
async def receive_movie_year(message: Message, state: FSMContext):
    year = None
    if message.text != "/skip":
        try:
            year = int(message.text)
        except ValueError:
            await message.answer("❌ Yil raqam bo'lishi kerak!")
            return
    await state.update_data(year=year)
    await state.set_state(MovieUpload.waiting_rating)
    await message.answer("⭐ Reytingni kiriting (0-10):\n(yoki /skip)")


@router.message(MovieUpload.waiting_rating)
async def receive_movie_rating(message: Message, state: FSMContext):
    rating = None
    if message.text != "/skip":
        try:
            rating = float(message.text)
        except ValueError:
            await message.answer("❌ Reyting raqam bo'lishi kerak!")
            return
    await state.update_data(rating=rating)
    await state.set_state(MovieUpload.waiting_is_serial)

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎬 Kino", callback_data="is_serial_0"),
        InlineKeyboardButton(text="📺 Serial", callback_data="is_serial_1")
    )
    await message.answer("Bu kino yoki serial?", reply_markup=builder.as_markup())


@router.callback_query(MovieUpload.waiting_is_serial, F.data.startswith("is_serial_"))
async def receive_is_serial(callback: CallbackQuery, state: FSMContext):
    is_serial = int(callback.data.split("_")[-1])
    await state.update_data(is_serial=is_serial)

    if is_serial:
        await state.set_state(MovieUpload.waiting_serial_code)
        await callback.message.answer("📺 Serial kodini kiriting (masalan: breaking_bad):")
    else:
        await save_movie(callback.message, state)
    await callback.answer()


@router.message(MovieUpload.waiting_serial_code)
async def receive_serial_code(message: Message, state: FSMContext):
    await state.update_data(serial_code=message.text.strip())
    await state.set_state(MovieUpload.waiting_season)
    await message.answer("🔢 Fasini kiriting (1, 2, ...):")


@router.message(MovieUpload.waiting_season)
async def receive_season(message: Message, state: FSMContext):
    try:
        season = int(message.text)
    except ValueError:
        await message.answer("❌ Fasl raqam bo'lishi kerak!")
        return
    await state.update_data(season=season)
    await state.set_state(MovieUpload.waiting_episode)
    await message.answer("📌 Qism raqamini kiriting:")


@router.message(MovieUpload.waiting_episode)
async def receive_episode(message: Message, state: FSMContext):
    try:
        episode = int(message.text)
    except ValueError:
        await message.answer("❌ Qism raqam bo'lishi kerak!")
        return
    await state.update_data(episode=episode)
    await save_movie(message, state)


async def save_movie(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()

    movie_id = await add_movie({
        "movie_code": data["movie_code"],
        "title": data["title"],
        "description": data.get("description", ""),
        "genre": data.get("genre", ""),
        "year": data.get("year"),
        "rating": data.get("rating"),
        "is_serial": data.get("is_serial", 0),
        "season": data.get("season"),
        "episode": data.get("episode"),
        "serial_code": data.get("serial_code"),
        "added_by": message.from_user.id
    })
    await add_movie_file(movie_id, data.get("quality", "HD"), data["file_id"], data.get("file_type", "video"))
    await add_log("Kino qo'shildi", message.from_user.id, f"{data['title']} ({data['movie_code']})")

    await message.answer(
        f"✅ <b>Kino saqlandi!</b>\n\n"
        f"🎬 <b>Nom:</b> {data['title']}\n"
        f"🔢 <b>Kod:</b> {data['movie_code']}\n"
        f"📺 <b>Sifat:</b> {data.get('quality', 'HD')}",
        reply_markup=admin_panel_keyboard(),
        parse_mode="HTML"
    )


# ==================== KINOLAR RO'YXATI ====================

@router.message(F.text == "🎥 Kinolar")
async def movies_list(message: Message):
    if not await is_admin(message.from_user.id):
        return
    movies = await get_all_movies(20)
    if not movies:
        await message.answer("📭 Kinolar yo'q.")
        return
    await message.answer(
        f"🎬 <b>Kinolar ({len(movies)} ta):</b>",
        reply_markup=movies_list_keyboard(movies),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("admin_movie_"))
async def admin_movie_detail(callback: CallbackQuery):
    movie_id = int(callback.data.split("_")[-1])
    movie = await get_movie_by_id(movie_id)
    if not movie:
        await callback.answer("❌ Topilmadi", show_alert=True)
        return
    text = (
        f"🎬 <b>{movie['title']}</b>\n"
        f"🔢 Kod: <code>{movie['movie_code']}</code>\n"
        f"📅 Yil: {movie['year'] or '?'}\n"
        f"⭐ Reyting: {movie['rating'] or '?'}\n"
        f"👁 Ko'rishlar: {movie['views']}"
    )
    await callback.message.answer(
        text,
        reply_markup=admin_movie_keyboard(movie_id),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("edit_title_"))
async def edit_title(callback: CallbackQuery, state: FSMContext):
    movie_id = int(callback.data.split("_")[-1])
    await state.set_state(MovieEdit.waiting_value)
    await state.update_data(movie_id=movie_id, field="title")
    await callback.message.answer("✏️ Yangi nomni kiriting:")
    await callback.answer()


@router.callback_query(F.data.startswith("edit_desc_"))
async def edit_desc(callback: CallbackQuery, state: FSMContext):
    movie_id = int(callback.data.split("_")[-1])
    await state.set_state(MovieEdit.waiting_value)
    await state.update_data(movie_id=movie_id, field="description")
    await callback.message.answer("📝 Yangi tavsifni kiriting:")
    await callback.answer()


@router.callback_query(F.data.startswith("edit_code_"))
async def edit_code(callback: CallbackQuery, state: FSMContext):
    movie_id = int(callback.data.split("_")[-1])
    await state.set_state(MovieEdit.waiting_value)
    await state.update_data(movie_id=movie_id, field="movie_code")
    await callback.message.answer("🔢 Yangi kodni kiriting:")
    await callback.answer()


@router.callback_query(F.data.startswith("edit_rating_"))
async def edit_rating(callback: CallbackQuery, state: FSMContext):
    movie_id = int(callback.data.split("_")[-1])
    await state.set_state(MovieEdit.waiting_value)
    await state.update_data(movie_id=movie_id, field="rating")
    await callback.message.answer("⭐ Yangi reytingni kiriting (0-10):")
    await callback.answer()


@router.message(MovieEdit.waiting_value)
async def save_edit(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    await update_movie(data["movie_id"], data["field"], message.text)
    await message.answer("✅ O'zgartirildi!", reply_markup=admin_panel_keyboard())


@router.callback_query(F.data.startswith("delete_movie_"))
async def confirm_delete(callback: CallbackQuery):
    movie_id = int(callback.data.split("_")[-1])
    from keyboards.keyboards import confirm_keyboard
    await callback.message.answer(
        "❓ Kinoni o'chirishga ishonchingiz komilmi?",
        reply_markup=confirm_keyboard("delete_movie", str(movie_id))
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm_delete_movie_"))
async def do_delete_movie(callback: CallbackQuery):
    movie_id = int(callback.data.split("_")[-1])
    await delete_movie(movie_id)
    await add_log("Kino o'chirildi", callback.from_user.id, str(movie_id))
    await callback.message.answer("✅ Kino o'chirildi!", reply_markup=admin_panel_keyboard())
    await callback.answer()


@router.callback_query(F.data == "cancel_action")
async def cancel_action(callback: CallbackQuery):
    await callback.message.answer("❌ Bekor qilindi.", reply_markup=admin_panel_keyboard())
    await callback.answer()
