from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder


# ==================== USER KEYBOARDS ====================

def main_menu_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="🔍 Kino qidirish"),
        KeyboardButton(text="🆕 Eng yangi kinolar")
    )
    builder.row(
        KeyboardButton(text="🏆 Top kinolar"),
        KeyboardButton(text="🎲 Tasodifiy kino")
    )
    builder.row(
        KeyboardButton(text="🎭 Janrlar"),
        KeyboardButton(text="📺 Seriallar")
    )
    builder.row(
        KeyboardButton(text="❤️ Sevimlilar"),
        KeyboardButton(text="👤 Profil")
    )
    builder.row(
        KeyboardButton(text="📨 Taklif va murojaat"),
        KeyboardButton(text="🆘 Support")
    )
    return builder.as_markup(resize_keyboard=True)


def admin_panel_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="📡 Kanallarni sozlash"),
        KeyboardButton(text="📊 Statistika")
    )
    builder.row(
        KeyboardButton(text="📢 Xabar yuborish"),
        KeyboardButton(text="🎬 Kino yuklash")
    )
    builder.row(
        KeyboardButton(text="🎥 Kinolar"),
        KeyboardButton(text="🆘 Support [Admin]")
    )
    builder.row(
        KeyboardButton(text="📋 Zayafkalar"),
        KeyboardButton(text="👥 Adminlar")
    )
    builder.row(
        KeyboardButton(text="🤖 Bot holati"),
        KeyboardButton(text="💾 Backup")
    )
    builder.row(
        KeyboardButton(text="⚙️ Sozlamalar"),
        KeyboardButton(text="🏠 Asosiy menyu")
    )
    return builder.as_markup(resize_keyboard=True)


def super_admin_panel_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="📡 Kanallarni sozlash"),
        KeyboardButton(text="📊 Statistika")
    )
    builder.row(
        KeyboardButton(text="📢 Xabar yuborish"),
        KeyboardButton(text="🎬 Kino yuklash")
    )
    builder.row(
        KeyboardButton(text="🎥 Kinolar"),
        KeyboardButton(text="🆘 Support [Admin]")
    )
    builder.row(
        KeyboardButton(text="📋 Zayafkalar"),
        KeyboardButton(text="👥 Adminlar")
    )
    builder.row(
        KeyboardButton(text="🤖 Bot holati"),
        KeyboardButton(text="💾 Backup")
    )
    builder.row(
        KeyboardButton(text="⚙️ Sozlamalar"),
        KeyboardButton(text="🏠 Asosiy menyu")
    )
    return builder.as_markup(resize_keyboard=True)


def back_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="🔙 Orqaga"))
    return builder.as_markup(resize_keyboard=True)


def cancel_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="❌ Bekor qilish"))
    return builder.as_markup(resize_keyboard=True)


def check_subscription_keyboard(channels: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for ch in channels:
        builder.row(InlineKeyboardButton(
            text=f"📢 {ch['channel_name'] or 'Kanal'}",
            url=ch['channel_link']
        ))
    builder.row(InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub"))
    return builder.as_markup()


def movie_keyboard(movie_id: int, is_fav: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    fav_text = "💔 Sevimlilardan o'chirish" if is_fav else "❤️ Sevimlilarga qo'shish"
    fav_data = f"unfav_{movie_id}" if is_fav else f"fav_{movie_id}"
    builder.row(InlineKeyboardButton(text=fav_text, callback_data=fav_data))
    builder.row(InlineKeyboardButton(text="📤 Do'stga ulashish", callback_data=f"share_{movie_id}"))
    return builder.as_markup()


def quality_keyboard(movie_id: int, files: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    quality_icons = {"HD": "📺", "Full HD": "🖥", "4K": "🎯"}
    for f in files:
        icon = quality_icons.get(f["quality"], "▶️")
        builder.row(InlineKeyboardButton(
            text=f"{icon} {f['quality']}",
            callback_data=f"play_{f['id']}"
        ))
    return builder.as_markup()


def genres_keyboard(genres: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    genre_icons = {
        "Komediya": "😂", "Dram": "😢", "Triller": "😱",
        "Kriminal": "🔫", "Romantik": "💕", "Animatsiya": "🎨",
        "Dokumentar": "📰", "Qo'rqinchli": "👻", "Fantastika": "🚀",
        "Jangari": "⚔️", "Sarguzasht": "🗺", "Biografik": "📖"
    }
    for genre in genres:
        icon = genre_icons.get(genre, "🎭")
        builder.button(text=f"{icon} {genre}", callback_data=f"genre_{genre}")
    builder.adjust(2)
    return builder.as_markup()


def serials_keyboard(serials: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for s in serials:
        builder.row(InlineKeyboardButton(
            text=f"📺 {s['title']}",
            callback_data=f"serial_{s['serial_code']}"
        ))
    return builder.as_markup()


def episodes_keyboard(episodes: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    current_season = None
    for ep in episodes:
        if ep['season'] != current_season:
            current_season = ep['season']
        builder.button(
            text=f"S{ep['season']}E{ep['episode']}",
            callback_data=f"movie_{ep['movie_code']}"
        )
    builder.adjust(4)
    return builder.as_markup()


def favorites_keyboard(movies: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for m in movies:
        builder.row(InlineKeyboardButton(
            text=f"🎬 {m['title']}",
            callback_data=f"movie_{m['movie_code']}"
        ))
    return builder.as_markup()


def movies_list_keyboard(movies: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for m in movies:
        builder.row(InlineKeyboardButton(
            text=f"🎬 {m['title']} ({m['movie_code']})",
            callback_data=f"admin_movie_{m['id']}"
        ))
    return builder.as_markup()


def admin_movie_keyboard(movie_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✏️ Nomini o'zgartirish", callback_data=f"edit_title_{movie_id}"),
        InlineKeyboardButton(text="📝 Tavsifni o'zgartirish", callback_data=f"edit_desc_{movie_id}")
    )
    builder.row(
        InlineKeyboardButton(text="🔢 Kodni o'zgartirish", callback_data=f"edit_code_{movie_id}"),
        InlineKeyboardButton(text="⭐ Reytingni o'zgartirish", callback_data=f"edit_rating_{movie_id}")
    )
    builder.row(
        InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"delete_movie_{movie_id}")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="admin_movies_back")
    )
    return builder.as_markup()


def channels_menu_keyboard() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="➕ Telegram kanal qo'shish"),
        KeyboardButton(text="📋 Kanallar ro'yxati")
    )
    builder.row(
        KeyboardButton(text="➕ Guruh qo'shish"),
        KeyboardButton(text="📋 Guruhlar ro'yxati")
    )
    builder.row(
        KeyboardButton(text="📸 Instagram qo'shish"),
        KeyboardButton(text="▶️ YouTube qo'shish")
    )
    builder.row(KeyboardButton(text="🔙 Orqaga"))
    return builder.as_markup(resize_keyboard=True)


def broadcast_type_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📝 Matn", callback_data="broadcast_text"),
        InlineKeyboardButton(text="🖼 Rasm", callback_data="broadcast_photo")
    )
    builder.row(
        InlineKeyboardButton(text="🎥 Video", callback_data="broadcast_video"),
        InlineKeyboardButton(text="📁 Fayl", callback_data="broadcast_file")
    )
    builder.row(InlineKeyboardButton(text="❌ Bekor qilish", callback_data="broadcast_cancel"))
    return builder.as_markup()


def confirm_keyboard(action: str, data: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Ha", callback_data=f"confirm_{action}_{data}"),
        InlineKeyboardButton(text="❌ Yo'q", callback_data="cancel_action")
    )
    return builder.as_markup()


def support_admin_keyboard(ticket_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="💬 Javob berish", callback_data=f"reply_ticket_{ticket_id}"),
        InlineKeyboardButton(text="✅ Yopish", callback_data=f"close_ticket_{ticket_id}")
    )
    return builder.as_markup()


def request_admin_keyboard(request_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Qabul qilish", callback_data=f"accept_req_{request_id}"),
        InlineKeyboardButton(text="❌ Rad etish", callback_data=f"reject_req_{request_id}")
    )
    builder.row(
        InlineKeyboardButton(text="💬 Javob yozish", callback_data=f"reply_req_{request_id}")
    )
    return builder.as_markup()


def bot_status_keyboard(current: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if current == "on":
        builder.row(InlineKeyboardButton(text="🔴 O'chirish", callback_data="bot_status_off"))
    else:
        builder.row(InlineKeyboardButton(text="🟢 Yoqish", callback_data="bot_status_on"))
    return builder.as_markup()


def movie_quality_select_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📺 HD", callback_data="quality_HD"),
        InlineKeyboardButton(text="🖥 Full HD", callback_data="quality_FHD"),
        InlineKeyboardButton(text="🎯 4K", callback_data="quality_4K")
    )
    return builder.as_markup()
