import os
from dotenv import load_dotenv

load_dotenv()

# Bot Token
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# Super Adminlar (o'zgartiring)
SUPER_ADMINS = [
    123456789  # Sizning Telegram ID
]

# Boshlang'ich adminlar (keyinchalik DB dan ham qo'shiladi)
INITIAL_ADMINS = [
    111111111,
    222222222
]

# Database
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///kinobot.db")

# Log fayl
LOG_FILE = "bot.log"

# Flood Control
FLOOD_RATE = 3      # soniyada
FLOOD_LIMIT = 5     # maksimal xabar soni

# Bot sozlamalari (DB dan o'zgartiriladi)
DEFAULT_BOT_NAME = "Kino Bot"
DEFAULT_START_TEXT = """🎬 Xush kelibsiz! 

Bu botda siz:
• Kino va seriallar ko'rishingiz
• Kinolarni saqlashingiz
• Yangi kinolar haqida xabar olishingiz mumkin!

Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling 👇"""

DEFAULT_SUPPORT_TEXT = "Savolingizni yozing, adminlar tez orada javob beradi:"
