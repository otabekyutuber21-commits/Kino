import time
from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message
from collections import defaultdict
from config import FLOOD_RATE, FLOOD_LIMIT

# {user_id: [timestamp, ...]}
user_requests: Dict[int, list] = defaultdict(list)


class FloodControlMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: Dict[str, Any]
    ) -> Any:
        if not isinstance(event, Message):
            return await handler(event, data)

        user_id = event.from_user.id
        now = time.time()

        # Eski so'rovlarni tozalash
        user_requests[user_id] = [
            t for t in user_requests[user_id] if now - t < FLOOD_RATE
        ]

        if len(user_requests[user_id]) >= FLOOD_LIMIT:
            await event.answer("⚠️ Juda tez xabar yuboryapsiz! Biroz kuting.")
            return

        user_requests[user_id].append(now)
        return await handler(event, data)
