import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN, LOG_FILE, SUPER_ADMINS, INITIAL_ADMINS
from database.db import init_db, get_db_admins
from middlewares.flood import FloodControlMiddleware

# Logging sozlash
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


async def notify_admins_startup(bot: Bot):
    """Bot ishga tushganda adminlarga xabar"""
    all_admins = set(SUPER_ADMINS + INITIAL_ADMINS + await get_db_admins())
    for admin_id in all_admins:
        try:
            await bot.send_message(admin_id, "✅ <b>Bot ishga tushdi!</b>", parse_mode="HTML")
        except Exception as e:
            logger.error(f"Startup notify error {admin_id}: {e}")


async def notify_admins_shutdown(bot: Bot):
    """Bot o'chganda adminlarga xabar"""
    all_admins = set(SUPER_ADMINS + INITIAL_ADMINS + await get_db_admins())
    for admin_id in all_admins:
        try:
            await bot.send_message(admin_id, "🔴 <b>Bot o'chdi!</b>", parse_mode="HTML")
        except:
            pass


async def main():
    # Database yaratish
    await init_db()
    logger.info("Database initialized")

    # Bot va Dispatcher
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher(storage=MemoryStorage())

    # Middleware
    dp.message.middleware(FloodControlMiddleware())

    # Handlerlarni ro'yxatdan o'tkazish
    from handlers.user import router as user_router
    from handlers.movies import router as movies_router
    from handlers.profile import router as profile_router
    from handlers.support import router as support_router
    from handlers.admin_movies import router as admin_movies_router
    from handlers.admin_channels import router as admin_channels_router
    from handlers.admin_panel import router as admin_panel_router

    dp.include_router(user_router)
    dp.include_router(movies_router)
    dp.include_router(profile_router)
    dp.include_router(support_router)
    dp.include_router(admin_movies_router)
    dp.include_router(admin_channels_router)
    dp.include_router(admin_panel_router)

    # Xato handler
    @dp.errors()
    async def error_handler(event, exception):
        logger.error(f"Update error: {exception}", exc_info=True)
        # Adminlarga xabar
        all_admins = set(SUPER_ADMINS + INITIAL_ADMINS + await get_db_admins())
        for admin_id in all_admins:
            try:
                await bot.send_message(
                    admin_id,
                    f"⚠️ <b>Bot xatosi:</b>\n<code>{str(exception)[:500]}</code>",
                    parse_mode="HTML"
                )
            except:
                pass
        return True

    logger.info("Bot starting...")

    # Webhook o'chirish (agar bo'lsa)
    await bot.delete_webhook(drop_pending_updates=True)

    # Startup xabari
    await notify_admins_startup(bot)

    try:
        logger.info("Bot polling started")
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await notify_admins_shutdown(bot)
        await bot.session.close()
        logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.critical(f"Critical error: {e}", exc_info=True)
