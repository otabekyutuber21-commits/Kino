import aiosqlite
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

DB_PATH = "kinobot.db"


async def init_db():
    """Barcha jadvallarni yaratish"""
    async with aiosqlite.connect(DB_PATH) as db:
        # Foydalanuvchilar
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                telegram_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                full_name TEXT,
                referred_by INTEGER,
                referral_count INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_banned INTEGER DEFAULT 0
            )
        """)

        # Adminlar (DB dan)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY,
                telegram_id INTEGER UNIQUE NOT NULL,
                added_by INTEGER,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                permissions TEXT DEFAULT 'all'
            )
        """)

        # Kanallar (majburiy obuna)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY,
                channel_id TEXT NOT NULL,
                channel_name TEXT,
                channel_link TEXT,
                channel_type TEXT DEFAULT 'telegram',
                is_required INTEGER DEFAULT 1,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Instagram/YouTube linklar
        await db.execute("""
            CREATE TABLE IF NOT EXISTS social_links (
                id INTEGER PRIMARY KEY,
                platform TEXT NOT NULL,
                link TEXT NOT NULL,
                title TEXT,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Kinolar
        await db.execute("""
            CREATE TABLE IF NOT EXISTS movies (
                id INTEGER PRIMARY KEY,
                movie_code TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                genre TEXT,
                year INTEGER,
                rating REAL,
                is_serial INTEGER DEFAULT 0,
                season INTEGER,
                episode INTEGER,
                serial_code TEXT,
                views INTEGER DEFAULT 0,
                added_by INTEGER,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Kino videolari (HD, FHD, 4K)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS movie_files (
                id INTEGER PRIMARY KEY,
                movie_id INTEGER NOT NULL,
                quality TEXT NOT NULL,
                file_id TEXT NOT NULL,
                file_type TEXT DEFAULT 'video',
                FOREIGN KEY (movie_id) REFERENCES movies(id)
            )
        """)

        # Sevimlilar
        await db.execute("""
            CREATE TABLE IF NOT EXISTS favorites (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                movie_id INTEGER NOT NULL,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, movie_id)
            )
        """)

        # Support xabarlari
        await db.execute("""
            CREATE TABLE IF NOT EXISTS support_messages (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                admin_id INTEGER,
                user_message TEXT,
                admin_message TEXT,
                status TEXT DEFAULT 'open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                replied_at TIMESTAMP
            )
        """)

        # Support suhbatlari (to'liq chat)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS support_chat (
                id INTEGER PRIMARY KEY,
                ticket_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                sender_type TEXT NOT NULL,
                message TEXT,
                message_id INTEGER,
                sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES support_messages(id)
            )
        """)

        # Zayafkalar (kino so'rovlari)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                movie_name TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                admin_reply TEXT,
                admin_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                replied_at TIMESTAMP
            )
        """)

        # Bot sozlamalari
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Loglar
        await db.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY,
                action TEXT NOT NULL,
                user_id INTEGER,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Referal tracking
        await db.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY,
                referrer_id INTEGER NOT NULL,
                referred_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        await db.commit()

        # Default sozlamalar
        defaults = [
            ("bot_name", "Kino Bot"),
            ("bot_status", "on"),
            ("start_text", "🎬 Xush kelibsiz! Botdan foydalanish uchun kanallarga obuna bo'ling."),
            ("support_text", "Savolingizni yozing:"),
            ("ad_text", ""),
            ("bot_photo", ""),
        ]
        for key, value in defaults:
            await db.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value)
            )
        await db.commit()

    logger.info("Database initialized successfully")


# ==================== USER ====================

async def get_user(telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        )
        return await cursor.fetchone()


async def create_user(telegram_id: int, username: str, full_name: str, referred_by: int = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT OR IGNORE INTO users (telegram_id, username, full_name, referred_by)
               VALUES (?, ?, ?, ?)""",
            (telegram_id, username, full_name, referred_by)
        )
        if referred_by:
            await db.execute(
                "UPDATE users SET referral_count = referral_count + 1 WHERE telegram_id = ?",
                (referred_by,)
            )
            await db.execute(
                "INSERT OR IGNORE INTO referrals (referrer_id, referred_id) VALUES (?, ?)",
                (referred_by, telegram_id)
            )
        await db.commit()


async def get_all_users():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT telegram_id FROM users WHERE is_banned = 0")
        rows = await cursor.fetchall()
        return [row[0] for row in rows]


async def get_user_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        total = (await (await db.execute("SELECT COUNT(*) FROM users")).fetchone())[0]
        today = (await (await db.execute(
            "SELECT COUNT(*) FROM users WHERE date(joined_at) = date('now')"
        )).fetchone())[0]
        week = (await (await db.execute(
            "SELECT COUNT(*) FROM users WHERE joined_at >= datetime('now', '-7 days')"
        )).fetchone())[0]
        month = (await (await db.execute(
            "SELECT COUNT(*) FROM users WHERE joined_at >= datetime('now', '-30 days')"
        )).fetchone())[0]
        return {"total": total, "today": today, "week": week, "month": month}


async def ban_user(telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET is_banned = 1 WHERE telegram_id = ?", (telegram_id,))
        await db.commit()


# ==================== ADMINS ====================

async def get_db_admins():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT telegram_id FROM admins")
        rows = await cursor.fetchall()
        return [row[0] for row in rows]


async def add_admin(telegram_id: int, added_by: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO admins (telegram_id, added_by) VALUES (?, ?)",
            (telegram_id, added_by)
        )
        await db.commit()


async def remove_admin(telegram_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM admins WHERE telegram_id = ?", (telegram_id,))
        await db.commit()


async def get_all_admins_info():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM admins ORDER BY added_at DESC")
        return await cursor.fetchall()


# ==================== CHANNELS ====================

async def get_channels(required_only=True):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if required_only:
            cursor = await db.execute(
                "SELECT * FROM channels WHERE is_required = 1 AND channel_type = 'telegram'"
            )
        else:
            cursor = await db.execute("SELECT * FROM channels WHERE channel_type = 'telegram'")
        return await cursor.fetchall()


async def add_channel(channel_id: str, channel_name: str, channel_link: str, channel_type='telegram'):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO channels (channel_id, channel_name, channel_link, channel_type) VALUES (?, ?, ?, ?)",
            (channel_id, channel_name, channel_link, channel_type)
        )
        await db.commit()


async def remove_channel(channel_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM channels WHERE id = ?", (channel_id,))
        await db.commit()


async def get_social_links(platform: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if platform:
            cursor = await db.execute("SELECT * FROM social_links WHERE platform = ?", (platform,))
        else:
            cursor = await db.execute("SELECT * FROM social_links")
        return await cursor.fetchall()


async def add_social_link(platform: str, link: str, title: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO social_links (platform, link, title) VALUES (?, ?, ?)",
            (platform, link, title)
        )
        await db.commit()


async def remove_social_link(link_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM social_links WHERE id = ?", (link_id,))
        await db.commit()


# ==================== MOVIES ====================

async def add_movie(data: dict) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """INSERT INTO movies (movie_code, title, description, genre, year, rating,
               is_serial, season, episode, serial_code, added_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data["movie_code"], data["title"], data.get("description", ""),
                data.get("genre", ""), data.get("year"), data.get("rating"),
                data.get("is_serial", 0), data.get("season"), data.get("episode"),
                data.get("serial_code"), data.get("added_by")
            )
        )
        await db.commit()
        return cursor.lastrowid


async def add_movie_file(movie_id: int, quality: str, file_id: str, file_type: str = "video"):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO movie_files (movie_id, quality, file_id, file_type) VALUES (?, ?, ?, ?)",
            (movie_id, quality, file_id, file_type)
        )
        await db.commit()


async def get_movie_by_code(code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM movies WHERE movie_code = ?", (code,))
        return await cursor.fetchone()


async def get_movie_by_id(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM movies WHERE id = ?", (movie_id,))
        return await cursor.fetchone()


async def search_movies_by_title(title: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE title LIKE ? AND is_serial = 0 ORDER BY views DESC LIMIT 10",
            (f"%{title}%",)
        )
        return await cursor.fetchall()


async def get_movie_files(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movie_files WHERE movie_id = ?", (movie_id,)
        )
        return await cursor.fetchall()


async def get_latest_movies(limit=10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE is_serial = 0 ORDER BY added_at DESC LIMIT ?", (limit,)
        )
        return await cursor.fetchall()


async def get_top_movies(limit=10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE is_serial = 0 ORDER BY views DESC LIMIT ?", (limit,)
        )
        return await cursor.fetchall()


async def get_random_movie():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE is_serial = 0 ORDER BY RANDOM() LIMIT 1"
        )
        return await cursor.fetchone()


async def get_movies_by_genre(genre: str, limit=10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE genre LIKE ? AND is_serial = 0 LIMIT ?",
            (f"%{genre}%", limit)
        )
        return await cursor.fetchall()


async def get_genres():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT DISTINCT genre FROM movies WHERE genre != ''")
        rows = await cursor.fetchall()
        genres = set()
        for row in rows:
            for g in row[0].split(","):
                g = g.strip()
                if g:
                    genres.add(g)
        return list(genres)


async def get_serials():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT DISTINCT serial_code, title FROM movies WHERE is_serial = 1 ORDER BY title"
        )
        return await cursor.fetchall()


async def get_serial_episodes(serial_code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies WHERE serial_code = ? ORDER BY season, episode",
            (serial_code,)
        )
        return await cursor.fetchall()


async def increment_views(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE movies SET views = views + 1 WHERE id = ?", (movie_id,))
        await db.commit()


async def update_movie(movie_id: int, field: str, value):
    allowed = ["title", "description", "genre", "year", "rating", "movie_code"]
    if field not in allowed:
        return
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE movies SET {field} = ? WHERE id = ?", (value, movie_id))
        await db.commit()


async def delete_movie(movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM movie_files WHERE movie_id = ?", (movie_id,))
        await db.execute("DELETE FROM movies WHERE id = ?", (movie_id,))
        await db.commit()


async def get_all_movies(limit=50, offset=0):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM movies ORDER BY added_at DESC LIMIT ? OFFSET ?", (limit, offset)
        )
        return await cursor.fetchall()


async def get_top_searched():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT title, views FROM movies ORDER BY views DESC LIMIT 5"
        )
        return await cursor.fetchall()


# ==================== FAVORITES ====================

async def add_favorite(user_id: int, movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "INSERT INTO favorites (user_id, movie_id) VALUES (?, ?)",
                (user_id, movie_id)
            )
            await db.commit()
            return True
        except Exception:
            return False


async def remove_favorite(user_id: int, movie_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM favorites WHERE user_id = ? AND movie_id = ?",
            (user_id, movie_id)
        )
        await db.commit()


async def get_favorites(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            """SELECT m.* FROM movies m
               JOIN favorites f ON m.id = f.movie_id
               WHERE f.user_id = ? ORDER BY f.added_at DESC""",
            (user_id,)
        )
        return await cursor.fetchall()


async def is_favorite(user_id: int, movie_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT id FROM favorites WHERE user_id = ? AND movie_id = ?",
            (user_id, movie_id)
        )
        return await cursor.fetchone() is not None


# ==================== SUPPORT ====================

async def create_support_ticket(user_id: int, message: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO support_messages (user_id, user_message) VALUES (?, ?)",
            (user_id, message)
        )
        ticket_id = cursor.lastrowid
        await db.execute(
            "INSERT INTO support_chat (ticket_id, sender_id, sender_type, message) VALUES (?, ?, 'user', ?)",
            (ticket_id, user_id, message)
        )
        await db.commit()
        return ticket_id


async def get_support_ticket(ticket_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM support_messages WHERE id = ?", (ticket_id,))
        return await cursor.fetchone()


async def get_user_open_ticket(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM support_messages WHERE user_id = ? AND status = 'open' ORDER BY created_at DESC LIMIT 1",
            (user_id,)
        )
        return await cursor.fetchone()


async def reply_support(ticket_id: int, admin_id: int, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE support_messages SET admin_id = ?, admin_message = ?, status = 'replied', replied_at = CURRENT_TIMESTAMP WHERE id = ?",
            (admin_id, message, ticket_id)
        )
        await db.execute(
            "INSERT INTO support_chat (ticket_id, sender_id, sender_type, message) VALUES (?, ?, 'admin', ?)",
            (ticket_id, admin_id, message)
        )
        await db.commit()


async def add_chat_message(ticket_id: int, sender_id: int, sender_type: str, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO support_chat (ticket_id, sender_id, sender_type, message) VALUES (?, ?, ?, ?)",
            (ticket_id, sender_id, sender_type, message)
        )
        await db.commit()


async def get_open_tickets():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM support_messages WHERE status = 'open' ORDER BY created_at DESC"
        )
        return await cursor.fetchall()


async def close_support_ticket(ticket_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE support_messages SET status = 'closed' WHERE id = ?", (ticket_id,)
        )
        await db.commit()


# ==================== REQUESTS (ZAYAFKA) ====================

async def create_request(user_id: int, movie_name: str, description: str = "") -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO requests (user_id, movie_name, description) VALUES (?, ?, ?)",
            (user_id, movie_name, description)
        )
        await db.commit()
        return cursor.lastrowid


async def get_request(request_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM requests WHERE id = ?", (request_id,))
        return await cursor.fetchone()


async def get_pending_requests():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM requests WHERE status = 'pending' ORDER BY created_at DESC"
        )
        return await cursor.fetchall()


async def update_request(request_id: int, status: str, admin_id: int, reply: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE requests SET status = ?, admin_id = ?, admin_reply = ?, replied_at = CURRENT_TIMESTAMP WHERE id = ?",
            (status, admin_id, reply, request_id)
        )
        await db.commit()


# ==================== SETTINGS ====================

async def get_setting(key: str, default: str = "") -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cursor.fetchone()
        return row[0] if row else default


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)",
            (key, value)
        )
        await db.commit()


# ==================== LOGS ====================

async def add_log(action: str, user_id: int = None, details: str = ""):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO logs (action, user_id, details) VALUES (?, ?, ?)",
            (action, user_id, details)
        )
        await db.commit()
