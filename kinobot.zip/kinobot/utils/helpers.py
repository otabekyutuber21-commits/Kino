import logging
from aiogram import Bot
from aiogram.types import ChatMember
from config import SUPER_ADMINS, INITIAL_ADMINS
from database.db import get_db_admins, get_channels, get_setting

logger = logging.getLogger(__name__)


async def is_super_admin(user_id: int) -> bool:
    return user_id in SUPER_ADMINS


async def is_admin(user_id: int) -> bool:
    if user_id in SUPER_ADMINS:
        return True
    if user_id in INITIAL_ADMINS:
        return True
    db_admins = await get_db_admins()
    return user_id in db_admins


async def check_subscription(bot: Bot, user_id: int) -> tuple[bool, list]:
    """Foydalanuvchi barcha kanallarga obuna bo'lganini tekshirish"""
    channels = await get_channels(required_only=True)
    not_subscribed = []

    for channel in channels:
        try:
            member: ChatMember = await bot.get_chat_member(channel["channel_id"], user_id)
            if member.status in ["left", "kicked", "banned"]:
                not_subscribed.append(channel)
        except Exception as e:
            logger.error(f"Channel check error {channel['channel_id']}: {e}")
            not_subscribed.append(channel)

    return len(not_subscribed) == 0, not_subscribed


async def is_bot_active() -> bool:
    status = await get_setting("bot_status", "on")
    return status == "on"


def format_movie_info(movie) -> str:
    """Kino ma'lumotlarini formatlash"""
    text = f"🎬 <b>{movie['title']}</b>\n\n"
    if movie['description']:
        text += f"📝 {movie['description']}\n\n"
    if movie['genre']:
        text += f"🎭 <b>Janr:</b> {movie['genre']}\n"
    if movie['year']:
        text += f"📅 <b>Yil:</b> {movie['year']}\n"
    if movie['rating']:
        text += f"⭐ <b>Reyting:</b> {movie['rating']}/10\n"
    text += f"\n👁 <b>Ko'rishlar:</b> {movie['views']}"
    return text


def format_serial_info(movie) -> str:
    text = f"📺 <b>{movie['title']}</b>\n"
    if movie['season']:
        text += f"🔢 <b>Fasl:</b> {movie['season']}\n"
    if movie['episode']:
        text += f"📌 <b>Qism:</b> {movie['episode']}\n"
    if movie['description']:
        text += f"\n📝 {movie['description']}\n"
    return text
